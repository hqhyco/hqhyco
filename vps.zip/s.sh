#!/bin/bash
chmod +x /caddy/caddy
chmod +x /ServerStatus/server/sergate
/caddy/caddy start
/ServerStatus/server/sergate