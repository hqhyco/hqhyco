#!/bin/bash
chmod +x /caddy/caddy
chmod +x /ServerStatus/server/sergate
cd /caddy
./caddy start
cd /ServerStatus/server
./sergate